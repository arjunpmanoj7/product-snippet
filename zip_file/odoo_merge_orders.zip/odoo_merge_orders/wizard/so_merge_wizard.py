# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Arjun P Manoj(odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import models, fields
from odoo.exceptions import ValidationError


class SaleOrderMergeWizard(models.TransientModel):
    _name = 'merge.sale'

    partner_id = fields.Many2one('res.partner',
                                 string='Customer Name',
                                 required=True
                                 )
    sale_order_ids = fields.Many2many('sale.order',
                                      string='Sale Order',
                                      required=True,
                                      domain="[('state','=','draft')]"
                                      )
    merge_type = fields.Selection(
        [('nothing', 'Keep Other Sale Order And Merge'),
         ('cancel', 'Cancel Other Sale Order And Merge'),
         ('remove', 'Remove Other Sale Order And Merge')],
        string='Merge Type', reuired=True, default='nothing')

    def merge_sale_order(self):
        if len(self.sale_order_ids) == 1:
            raise ValidationError('Select at least 2 Sale order to Merge')



        else:

            sale_order = self.env['sale.order'].create({
                'partner_id': self.partner_id.id})
            for rec in self.sale_order_ids.order_line:
                sale_order.write(
                    {'order_line': [(0, 0, {'product_id': rec.product_id.id,
                                            'name': rec.name,
                                            'price_unit': rec.price_unit,
                                            'product_uom_qty': rec.product_uom_qty})]

                     })

            if self.merge_type == 'cancel':
                self.sale_order_ids.action_cancel()
            elif self.merge_type == 'remove':
                self.sale_order_ids.action_cancel()
                self.sale_order_ids.unlink()
