# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Arjun P Manoj (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import models, fields
from odoo.exceptions import ValidationError


class StockPickingMergeWizard(models.TransientModel):
    _name = 'merge.stock.picking'

    stock_pickings_ids = fields.Many2many('stock.picking',
                                          string='Stock Picking',
                                          required=True
                                          )
    merge_type = fields.Selection(
        [('nothing', 'Keep Other Stock Picking And Merge'),
         ('cancel', 'Cancel Other  Stock Picking And Merge')],
        string='Merge Type', reuired=True, default='nothing')

    def merge_stock_picking(self):
        state = []
        draft = 'assigned'
        partner = []
        operation = []
        origin = []
        for rec in self.stock_pickings_ids:
            state.append(rec.state)
            partner.append(rec.partner_id.id)
            operation.append(rec.picking_type_id.id)
            origin.append(rec.origin)
        state.append(draft)
        val = all(ele == state[-1] for ele in state)

        if len(self.stock_pickings_ids) == 1:
            raise ValidationError('Select at least 2 Transfer to Merge')

        if not val:
            raise ValidationError('Only Transfer in Ready State can Merge')

        if val and len(self.stock_pickings_ids) > 1:
            stock_picking = self.env['stock.picking'].create({
                'partner_id': partner[0],
                'picking_type_id': operation[0],
                'origin': origin[0]
            })
            for res in self.stock_pickings_ids.move_ids:
                stock_picking.write(
                    {'move_ids': [(0, 0, {'product_id': res.product_id.id,
                                          'product_uom_qty': res.product_uom_qty,
                                          'product_uom': res.product_uom.id,
                                          'name': res.name,
                                          'location_id': res.location_id.id,
                                          'location_dest_id': res.location_dest_id.id,
                                          'quantity_done': res.quantity_done})]

                     })
            if self.merge_type == 'cancel':
                self.stock_pickings_ids.action_cancel()
