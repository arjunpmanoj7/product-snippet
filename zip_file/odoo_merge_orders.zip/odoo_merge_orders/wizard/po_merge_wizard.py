# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Arjun P Manoj(odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import models, fields
from odoo.exceptions import ValidationError


class PoMergeWizard(models.TransientModel):
    _name = 'merge.purchase'

    partner_id = fields.Many2one('res.partner',
                                 string='Vendor Name',
                                 required=True
                                 )
    purchase_order_ids = fields.Many2many('purchase.order',
                                          string='Purchase Order',
                                          required=True,
                                          domain="[('state','=','draft')]"
                                          )
    merge_type = fields.Selection(
        [('nothing', 'Keep Other Purchase Order And Merge'),
         ('cancel', 'Cancel Other Purchase Order And Merge'),
         ('remove', 'Remove Other Purchase Order And Merge')],
        string='Merge Type', reuired=True, default='nothing')

    def merge_purchase_order(self):

        if len(self.purchase_order_ids) == 1:
            raise ValidationError('Select at least 2 Purchase order to Merge')

        else:
            purchase_order = self.env['purchase.order'].create({
                'partner_id': self.partner_id.id})
            for rec in self.purchase_order_ids.order_line:
                purchase_order.write(
                    {'order_line': [(0, 0, {'product_id': rec.product_id.id,
                                            'name': rec.name,
                                            'price_unit': rec.price_unit,
                                            'product_qty': rec.product_qty})]

                     })

            if self.merge_type == 'cancel':
                self.purchase_order_ids.button_cancel()
            elif self.merge_type == 'remove':
                self.purchase_order_ids.button_cancel()
                self.purchase_order_ids.unlink()
