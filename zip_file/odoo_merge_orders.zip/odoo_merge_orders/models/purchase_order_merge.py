# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Arjun P Manoj(odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import models, fields
from odoo.exceptions import ValidationError


class MergePurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def action_purchase_order(self):
        state = []
        draft = 'draft'
        for rec in self.env.context['active_ids']:
            merge_order = self.env['purchase.order'].browse(rec)
            for res in merge_order:
                state.append(res.state)
        state.append(draft)
        val = all(ele == state[-1] for ele in state)
        if (val):
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'merge.purchase',
                'view_mode': 'form',
                'target': 'new',
                'context': {
                    'default_purchase_order_ids': self.env.context.get(
                        'active_ids')}

            }
        else:
            raise ValidationError('Must Be In Request For Quotations')
