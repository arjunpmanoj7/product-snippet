# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Arjun P Manoj (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import models, fields
from odoo.exceptions import ValidationError


class MergeSaleOrder(models.Model):
    _inherit = 'stock.picking'

    def action_stock_picking(self):
        partner = []
        operation_type = []
        for rec in self.env.context.get('active_ids'):
            stock_pickings = self.env['stock.picking'].browse(rec)
            for val in stock_pickings:
                partner.append(val.partner_id.id)
                operation_type.append(val.picking_type_id.id)

        res = all(ele == partner[0] for ele in partner)
        picking_type = all(ele == operation_type[0] for ele in operation_type)

        if not res:
            raise ValidationError('Can Only Merge Transfer Of Same Partner')
        if not picking_type:
            raise ValidationError('Select Same Operation Type')

        if res and picking_type:
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'merge.stock.picking',
                'view_mode': 'form',
                'target': 'new',
                'context': {
                    'default_stock_pickings_ids': self.env.context.get(
                        'active_ids')}
            }
