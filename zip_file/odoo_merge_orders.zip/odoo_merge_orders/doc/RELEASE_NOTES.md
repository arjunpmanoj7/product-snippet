## Module <odoo_merge_orders>

#### 30.07.2022
#### Version 16.0.1.0.0
#### ADD

- Initial commit for odoo - merge orders
