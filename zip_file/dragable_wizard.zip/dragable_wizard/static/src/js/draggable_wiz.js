/** @odoo-module **/


import { patch } from "@web/core/utils/patch";
import { Dialog } from "@web/core/dialog/dialog";

const { Component, useExternalListener, onMounted } = owl;

patch(Dialog.prototype,'dialog_patch',{
    setup() {
        this._super.apply();
        onMounted(this.mount)
    },
    mount(){
        this.__owl__.bdom.children[0].parentEl.addEventListener('click', this.draggable)
    },
    draggable(el) {

          el.target.addEventListener('mousedown', function(e) {
            var offsetX = e.clientX - parseInt(window.getComputedStyle(this).left);
            var offsetY = e.clientY - parseInt(window.getComputedStyle(this).top);

            function mouseMoveHandler(e) {
              el.target.style.top = (e.clientY - offsetY) + 'px';
              el.target.style.left = (e.clientX - offsetX) + 'px';
            }

            function reset() {
              window.removeEventListener('mousemove', mouseMoveHandler);
              window.removeEventListener('mouseup', reset);
            }

            window.addEventListener('mousemove', mouseMoveHandler);
            window.addEventListener('mouseup', reset);
        });
    },
});