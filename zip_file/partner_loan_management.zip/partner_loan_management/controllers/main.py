from odoo import http, _
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal


class PortalAccount(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        user_id = request.uid
        user = request.env['res.users'].sudo().browse(user_id)

        if user.has_group('partner_loan_management.partner_loan_manager'):
            if 'loan_count' in counters:
                loan_count = request.env['loan.request'].search_count(
                    [('state', '=', 'posted')])
                values['loan_count'] = loan_count
        else:
            if 'loan_count' in counters:
                loan_count = request.env['loan.request'].search_count(
                    [('partner_id', '=', user.partner_id.id),
                     ('state', '=', 'posted')])
                values['loan_count'] = loan_count

        return values

    @http.route("/my/loan", type="http", auth="user",
                methods=['GET'], website=True)
    def portal_my_loan(self):
        user_id = request.uid
        user = request.env['res.users'].sudo().browse(user_id)
        if user.has_group('partner_loan_management.partner_loan_manager'):
            loan_1 = request.env['loan.request'].sudo().search(
                [('state', '=', 'approved')])
            values = {
                'loan': loan_1,
            }

        else:
            loan_2 = request.env['loan.request'].search(
                [('partner_id', '=', user.partner_id.id),
                 ('state', '=', 'approved')])
            values = {
                'loan': loan_2,
            }

        return request.render("partner_loan_management.portal_my_loans",
                              values)

    @http.route("/my/<int:id>", type="http", auth="user",
                methods=['GET'], website=True)
    def loan_view(self, id):
        loan = request.env['loan.request'].sudo().browse(id)

        values = {
            'loan': loan,
        }

        return request.render("partner_loan_management.portal_my_loan", values)
