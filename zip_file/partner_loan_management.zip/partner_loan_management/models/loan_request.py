from odoo import fields, models, api
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError


class LoanRequest(models.Model):
    _name = 'loan.request'
    _inherit = "mail.thread", "mail.activity.mixin"
    name = fields.Char(compute='compute_name', store=True)
    partner_id = fields.Many2one('res.partner', string='Partner Name',
                                 required=True)
    loan_type = fields.Many2one('loan.types')
    requesting_amount = fields.Float(string='Amount Request')
    date_today = fields.Date(string='Request Date', required=True)
    loan_closing_date = fields.Date(readonly=True, store=True)
    loan_installment_ids = fields.One2many('loan.installment',
                                           'loan_request_id')
    interest_rate = fields.Float(related="loan_type.rate",
                                 string='Interest Rate %')
    total_months = fields.Integer(related="loan_type.total_months")
    check = fields.Boolean()
    total_amount = fields.Float(compute='compute_total_amount', store=True)
    reminder = fields.Char()
    proofs_ids = fields.Many2many('loan.proof', compute='check_proofs',
                                  store=True)

    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('to_approve', 'To Approve'),
        ('approved', 'Approved'), ('posted', 'Posted')], default='draft')

    @api.depends('loan_type')
    def check_proofs(self):
        for rec in self:
            rec.proofs_ids = rec.loan_type.loan_proofs_ids.ids

    @api.onchange('date_today')
    def closing_date(self):

        try:
            self.loan_closing_date = self.date_today + relativedelta(
                months=self.loan_type.total_months)
        except:
            pass

    @api.depends('loan_installment_ids.total')
    def compute_total_amount(self):
        for line in self:
            line.total_amount = sum(
                line.mapped('loan_installment_ids').mapped('total'))

    @api.depends('loan_type', 'partner_id')
    def compute_name(self):
        try:
            for val in self:
                val.name = val.loan_type.name + '-' + val.partner_id.name
        except:
            pass

    @api.onchange('requesting_amount')
    def check_request_amount(self):

        max_amount = self.loan_type.amount_limit

        if self.requesting_amount > float(max_amount):
            raise ValidationError(f'Limit reached{max_amount}')

    def button_compute(self):

        for rec in self:
            self.write({'loan_installment_ids': [(5, 0, 0)]})
            total_interest = (
                                     self.requesting_amount * self.loan_type.rate) / 100
            principal_amount = self.requesting_amount / self.loan_type.total_months
            start_date = rec.date_today
            num = 1
            for i in range(1, self.loan_type.total_months + 1):
                self.write(
                    {'loan_installment_ids': [(0, 0, {
                        'installment_number': num,
                        'date_from': start_date,
                        'date_to': start_date + relativedelta(months=1),
                        'interest_amount': total_interest / self.loan_type.total_months,
                        'principal_amount': principal_amount,
                        'total': principal_amount + total_interest / self.loan_type.total_months,
                        'loan_request_id': self.id,
                        'loan_partner_id': self.partner_id.id

                    })]})
                num += 1
                start_date = start_date + relativedelta(months=1)

    def to_approve(self):
        partner_check = []
        loan_request = self.env['loan.request'].search(
            [('partner_id', '=', self.partner_id.id)])
        for request in loan_request:
            partner_check.append(request.id)
            if len(partner_check) > 1:
                self.write({'reminder': "partner have another lone"})

        partner_category = []
        for rec in self.loan_type.partner_category:
            partner_category.append(rec.id)

        self.check = False
        for res in self.partner_id.category_id:

            if res.id in partner_category:
                self.state = 'to_approve'
                self.check = True
        if not self.check:
            raise ValidationError('your not eligible for this loan')

    def approved(self):

        self.state = 'approved'


    def button_draft(self):
        self.state = 'draft'

    def post_loan(self):

        self.state = 'posted'
        loan_installment = self.env['loan.installment'].search(
            [('loan_request_id', '=', self.id)])
        loan_installment.check = True
        self.env['account.move'].create({
            'ref': self.name,
            'loan_request_id': self.id,

            'line_ids': [
                (0, 0, {
                    'partner_id': self.partner_id.id,
                    'account_id': self.loan_type.interest_account.id,
                    'credit': self.requesting_amount
                }),
                (0, 0, {
                    'partner_id': self.partner_id.id,
                    'account_id': self.partner_id.property_account_receivable_id.id,
                    'debit': self.requesting_amount
                }),
            ],

        }).action_post()

    def journal_entry_show(self):
        return {
            'name': 'Loan Entry',
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'view_type': 'form',
            'target': 'current',
            'domain': [('loan_request_id', '=', self.id)]

        }


class LoanProof(models.Model):
    _name = 'loan.proof'
    proof = fields.Char(string='proof')
    mandatory = fields.Boolean(string='mandatory')


class InheritAccountMove(models.Model):
    _inherit = 'account.move'

    loan_request_id = fields.Many2one('loan.request')
