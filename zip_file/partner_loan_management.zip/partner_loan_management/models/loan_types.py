from odoo import fields, models


class LoanType(models.Model):
    _name = 'loan.types'
    _inherit = "mail.thread", "mail.activity.mixin"

    name = fields.Char(string='Loan Name')
    amount_limit = fields.Char(string='Maximum Loan Amount')
    total_months = fields.Integer(string='Loan Duration/in months')
    rate = fields.Float(string='Interest Rate')
    interest_account = fields.Many2one('account.account')
    partner_category = fields.Many2many('res.partner.category')
    loan_proofs_ids = fields.Many2many('loan.proof')
