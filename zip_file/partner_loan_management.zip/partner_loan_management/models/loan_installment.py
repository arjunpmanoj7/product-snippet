from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)
class ComputeLoan(models.Model):
    _name = 'loan.installment'
    _inherit = "mail.thread", "mail.activity.mixin"

    date_from = fields.Date()
    date_to = fields.Date()
    principal_amount = fields.Float()
    interest_amount = fields.Float()
    total = fields.Float()
    loan_request_id = fields.Many2one('loan.request')
    loan_partner_id = fields.Many2one('res.partner')
    installment_number = fields.Integer()
    installment_payment_id = fields.Many2one('account.payment',readonly=True)
    check = fields.Boolean()
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'), ('posted', 'Posted')
    ], default='draft')


    def view_installment(self):

        return {
            'name':'Loan Installment',
            'type': 'ir.actions.act_window',
            'res_model': 'loan.installment',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
            'res_id':self.id


        }

    def request_payment(self):
        return {
            'name':'Request Payment',
            'type': 'ir.actions.act_window',
            'res_model': 'loan.register.payment',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {'default_amount': self.total,
                        'default_partner_id':self.loan_partner_id

                        }
        }

    def approve_payment(self):
        payment = self.env['account.payment'].browse(
            self.installment_payment_id.id)
        payment.action_post()
        self.state = 'approved'


