from odoo import fields, models, api
from dateutil.relativedelta import relativedelta


class InheritResPartner(models.Model):
    _inherit = 'res.partner'
    loan_request_ids = fields.One2many('loan.partner', 'loan_partner_id')
    loan_check = fields.Boolean(compute='_compute_loan', readonly=False)
    total_loan_amount = fields.Float(compute='compute_total_amount')

    @api.depends('loan_request_ids.total_amount')
    def compute_total_amount(self):
        for line in self:
            line.total_loan_amount = sum(
                line.mapped('loan_request_ids').mapped('total_amount'))

    @api.depends('name')
    def _compute_loan(self):
        loan_request = self.env['loan.request'].search(
            [('partner_id', '=', self.id)])
        self.write({'loan_request_ids': [(5, 0, 0)]})
        for rec in loan_request:
            self.write(
                {'loan_request_ids': [(0, 0, {
                    'loan_type': rec.loan_type.id,
                    'name': rec.name,
                    'date_today': rec.date_today,
                    'loan_closing_date': rec.loan_closing_date,
                    'total_months': rec.total_months,
                    'total_amount': rec.total_amount,
                    'loan_request_id':rec.id


                })]})


class LoanPartnerView(models.Model):
    _name = 'loan.partner'

    name = fields.Char()
    loan_type = fields.Many2one('loan.types')
    date_today = fields.Date()
    loan_closing_date = fields.Date()
    total_months = fields.Integer()
    total_amount = fields.Float()
    loan_partner_id = fields.Many2one('res.partner')
    loan_request_id = fields.Many2one('loan.request')

    def view_loan(self):

        return {
            'name': 'Loan',
            'type': 'ir.actions.act_window',
            'res_model': 'loan.request',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
            'res_id':self.loan_request_id.id

        }


