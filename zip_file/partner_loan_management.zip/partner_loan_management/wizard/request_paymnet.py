from odoo import fields, models, api


class RegisterLoanPayment(models.TransientModel):
    _name = 'loan.register.payment'

    journal_id = fields.Many2one('account.journal', required=True)
    payment_method = fields.Many2one('account.payment.method.line',required=True)
    amount = fields.Float(readonly=True)
    payment_date = fields.Date(default=fields.Date.context_today,readonly=True)
    memo = fields.Char(compute='compute_memo',readonly=True)
    partner_id = fields.Many2one('res.partner')

    @api.depends('amount')
    def compute_memo(self):
        installment = self.env['loan.installment'].browse(
            self.env.context.get('active_id'))
        loan_request = self.env['loan.request'].search(
            [('loan_installment_ids', '=', installment.id)])
        print(loan_request.name)
        self.memo = loan_request.name + str(self.payment_date)


    def loan_payment(self):
        payment = self.env['account.payment'].create({
            'amount': self.amount,
            'ref':self.memo,
            'partner_id': self.partner_id.id,
            'date': self.payment_date,
            'currency_id': self.env.company.currency_id.id,
            'payment_type': 'inbound',
            'partner_type': 'customer',
        })
        installment = self.env['loan.installment'].browse(
            self.env.context.get('active_id'))
        installment.state = 'requested'
        installment.write({'installment_payment_id': payment.id})
