from odoo import fields, models


class LoanManagementPdf(models.TransientModel):
    _name = 'loan.pdf'

    date_from = fields.Date()
    date_to = fields.Date()
    loan_type = fields.Many2one('loan.types')

    def print_loan_pdf(self):
        print('heloo')
        new_query = ''
        query = """
                select loan_request.name as "loan_name",loan_request.date_today,loan_request.loan_closing_date,
                loan_types.total_months,loan_types.rate,loan_request.requesting_amount,
                loan_request.total_amount,res_partner.name from loan_request 
                join loan_types on loan_request.loan_type=loan_types.id join
                 res_partner on loan_request.partner_id=res_partner.id
               """
        if self.date_from:
            new_query = """and loan_request.date_today >= '{date_from}' """.format(
                date_from=self.date_from)
            query += new_query
        if self.date_to:
            new_query = """and loan_request.date_today <= '{date_to}' """.format(
                date_to=self.date_to)
            query += new_query
        if self.loan_type:
            new_query = """ and loan_request.loan_type ='{loan_type}' """.format(
                loan_type=self.loan_type.id)
            query += new_query
        self.env.cr.execute(query)
        record = self.env.cr.dictfetchall()
        print(record)
        # print('comp', self.env.company.external_report_layout_id)
        data = {
            'response': record,
            'loan_type': self.loan_type.name,
            'from_date': self.date_from,
            'to_date': self.date_to
        }
        print(data)
        report_action = self.env.ref(
            'partner_loan_management.action_report_loan_management').report_action(
            self, data=data)
        return report_action
