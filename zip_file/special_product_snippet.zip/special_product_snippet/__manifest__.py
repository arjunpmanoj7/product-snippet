{
    'name': 'special product website snippet',
    'version': '16.0.1.0.0',
    'summary': """special product website snippet""",
    'category': 'Tools',
    'description': """special product website snippet""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'maintainer': 'Cybrosys Techno Solutions',
    'website': "https://cybrosys.com/",
    'depends': ['sale_management', 'website', 'base', 'stock'],
    'data': ['views/product_snippet_template.xml',
             'views/special_products_snippet_template.xml',
             'views/product_snippets_option.xml',
             ],
    'assets': {
        'web.assets_frontend': [
            'special_product_snippet/static/src/css/product_snippet.css',
            'special_product_snippet/static/src/js/000.js',
        ],
        'website.assets_wysiwyg': [
          '/special_product_snippet/static/src/js/options.js'
        ],

    },
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
