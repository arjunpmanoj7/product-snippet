odoo.define('special_product_snippet.special_product_snippet_options', function (require) {
'use strict';
console.log('ujnrhjjjjjjmfnref')
const options = require('web_editor.snippets.options');
const dynamicSnippetOptions = require('website.s_dynamic_snippet_options');
var wUtils = require('website.utils');

const dynamicSnippetSpecialProductOptions = dynamicSnippetOptions.extend({



});

options.registry.dynamic_snippet_special_products_options = dynamicSnippetSpecialProductOptions;

return dynamicSnippetSpecialProductOptions;
});