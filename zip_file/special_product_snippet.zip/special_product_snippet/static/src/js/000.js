/** @odoo-module **/

import publicWidget from 'web.public.widget';
import DynamicSnippet from 'website.s_dynamic_snippet';

const DynamicSnippetSpecialProduct = DynamicSnippet.extend({
    selector: '.s_dynamic_snippet_special_product',
    disabledInEditableMode: false,
});
publicWidget.registry.special_product = DynamicSnippetSpecialProduct;

