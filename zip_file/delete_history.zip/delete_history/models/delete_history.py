from odoo import models, fields


class DeleteHistory(models.Model):
    _name = 'delete.history'

    name = fields.Char(
        string='Name'
    )
    model_id = fields.Many2one('ir.model',
                               string="Model")

    user_id = fields.Many2one('res.users',
                              string="Deleted User")

    deleted_date = fields.Date(
        string='Deleted Date'
    )
    record = fields.Integer(
        string = 'Record Id'
    )
