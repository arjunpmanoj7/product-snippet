from odoo import fields, models


class DeleteHistoryAction(models.AbstractModel):
    _inherit = 'base'

    def unlink(self):
        exclude_models = ['delete.history', 'ir.attachment',
                         'ir.model.data', 'mail.followers']
        if self._name not in exclude_models:
            model_name = self._name
            models_record = self.env['ir.model'].sudo().search(
                [('model', '=', model_name)])

            for rec in self:
                if rec._fields.get('name'):
                    self.env['delete.history'].create({
                        'model_id': models_record.id,
                        'name': rec.name,
                        'record': rec.id,
                        'user_id': self.env.user.id,
                        'deleted_date': fields.date.today(),
                    })
        return super(DeleteHistoryAction, self).unlink()
